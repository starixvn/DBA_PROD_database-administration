

set nocount on
create table __annual_archive_date (datefrom smalldatetime, dateto smalldatetime)
insert into __annual_archive_date(datefrom, dateto) values('2020-01-01', '2021-01-01')

go
begin --translog_BK
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime
		, @max_wld smalldatetime
	select @eventdate = min(winlostdate) from dbo.translog_BK with(nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date
	while @eventdate < @datefrom
	begin 
	
		delete from dbo.translog_BK
		where winlostdate = @eventdate

		set @message = 'translog_BK ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	--///
	set @eventdate = @dateto
	select @max_wld = max(winlostdate) from dbo.translog_BK
	while @eventdate <= @max_wld
	begin 
	
		delete from dbo.translog_BK
		where winlostdate = @eventdate
	
		set @message = 'translog_BK ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end
end

go
begin --TOControl_Setting_bk
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime, @max_wld smalldatetime
	select @eventdate = min(eventdate) from dbo.match_bk with(nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date

	declare @__matchIds table(matchid int primary key)

	while @eventdate < @datefrom
	begin 
	
		delete from @__matchIds
		insert into @__matchIds select matchid from dbo.match_bk with(nolock) where eventdate = @eventdate
		
		delete s
		from dbo.TOControl_Setting_bk s where winlostdate = @eventdate
	
		set @message = 'TOControl_Setting_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	--///
	set @eventdate = @dateto
	select @max_wld = max(winlostdate) from dbo.TOControl_Setting_bk
	while @eventdate <= @max_wld
	begin 
	
		delete from @__matchIds
		insert into @__matchIds select matchid from dbo.match_bk with(nolock) where eventdate = @eventdate

		delete s
		from dbo.TOControl_Setting_bk s where winlostdate = @eventdate
	
		set @message = 'TOControl_Setting_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	--//last round
	delete from dbo.TOControl_Setting_bk where winlostdate is null
end

go
begin --BetParlayResult
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime, @max_wld smalldatetime
	select @eventdate = min(eventdate) from dbo.match_bk with(nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date

	while @eventdate < @datefrom
	begin 
	
		delete s
		from dbo.BetParlayResult s
		where winlostdate = @eventdate
	
		set @message = 'BetParlayResult ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	--///
	set @eventdate = @dateto
	select @max_wld = max(winlostdate) from dbo.BetParlayResult
	while @eventdate <= @max_wld
	begin 
	
		delete s
		from dbo.BetParlayResult s
		where winlostdate = @eventdate
	
		set @message = 'BetParlayResult ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end
end

go
begin --betParlayResult_Archive
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime, @max_wld smalldatetime
	select @eventdate = min(eventdate) from dbo.match_bk with(nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date

	while @eventdate < @datefrom
	begin 
	
		delete s
		from dbo.betParlayResult_Archive s
		where winlostdate = @eventdate
	
		set @message = 'betParlayResult_Archive ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	--///
	set @eventdate = @dateto
	select @max_wld = max(winlostdate) from dbo.betParlayResult_Archive
	while @eventdate <= @max_wld
	begin 
	
		delete s
		from dbo.betParlayResult_Archive s
		where winlostdate = @eventdate
	
		set @message = 'betParlayResult_Archive ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end
end

--====
go
begin --Odds3rd_bk
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime, @max_wld smalldatetime
	select @eventdate = min(eventdate) from dbo.match_bk with(nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date

	declare @__matchIds table(matchid int primary key)

	while @eventdate < @datefrom
	begin
	
		delete from @__matchIds
		insert into @__matchIds 
		select matchid from dbo.match_bk with(nolock) where eventdate = @eventdate
		group by matchid

		delete s
		from dbo.Odds3rd_bk s
		where exists (select top 1 1 from @__matchIds t where s.matchid = t.matchid)
	
		set @message = 'Odds3rd_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	--///
	set @eventdate = @dateto
	select @max_wld = max(eventdate) from dbo.match_bk
	while @eventdate <= @max_wld
	begin 
	
		delete from @__matchIds
		insert into @__matchIds 
		select matchid from dbo.match_bk with(nolock) where eventdate = @eventdate
		group by matchid

		delete s
		from dbo.Odds3rd_bk s
		where exists (select top 1 1 from @__matchIds t where s.matchid = t.matchid)
	
		set @message = 'Odds3rd_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end
end

go
begin --Odds_bk
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime, @max_wld smalldatetime
	select @eventdate = min(eventdate) from dbo.match_bk with(nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date

	declare @__matchIds table(matchid int primary key)

	while @eventdate < @datefrom
	begin
	
		delete from @__matchIds
		insert into @__matchIds 
		select matchid from match_bk where eventdate = @eventdate
		group by matchid

		delete s
		from dbo.Odds_bk s
		where exists (select top 1 1 from @__matchIds t where s.matchid = t.matchid)
	
		set @message = 'Odds_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	--///
	set @eventdate = @dateto
	select @max_wld = max(eventdate) from dbo.match_bk
	while @eventdate <= @max_wld
	begin 
	
		delete from @__matchIds
		insert into @__matchIds 
		select matchid from match_bk where eventdate = @eventdate
		group by matchid

		delete s
		from dbo.Odds_bk s
		where exists (select top 1 1 from @__matchIds t where s.matchid = t.matchid)
	
		set @message = 'Odds_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end
end

go
begin ---match_remark
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime, @max_wld smalldatetime
	select @eventdate = min(eventdate) from dbo.match_bk with (nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date
	while @eventdate < @datefrom
	begin 
	
		delete r
		from dbo.match_remark r
			inner join dbo.match_bk m on r.matchid = m.matchid
		where eventdate = @eventdate
	
		set @message = 'match_remark ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	set @eventdate = @dateto
	select @max_wld = max(eventdate) from dbo.match_bk
	while @eventdate <= @max_wld
	begin 
	
		delete r
		from dbo.match_remark r
			inner join dbo.match_bk m on r.matchid = m.matchid
		where eventdate = @eventdate
	
		set @message = 'match_remark ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end
end

go
begin --VSOutright_bk
	declare @datefrom smalldatetime, @dateto smalldatetime
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date
	delete dbo.VSOutright_bk where eventdate < @datefrom or eventdate >= @dateto
end

go
begin ---match_bk ==> last table
	declare @eventdate smalldatetime, @message varchar(2000), @datefrom smalldatetime, @dateto smalldatetime, @max_wld smalldatetime
	select @eventdate = min(eventdate) from dbo.match_bk with (nolock)
	select @datefrom = datefrom, @dateto = dateto from __annual_archive_date
	while @eventdate < @datefrom
	begin 
	
		delete m
		from dbo.match_bk m
		where eventdate = @eventdate
	
		set @message = 'match_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end

	set @eventdate = @dateto
	select @max_wld = max(eventdate) from dbo.match_bk
	while @eventdate <= @max_wld
	begin 
	
		delete m
		from dbo.match_bk m
		where eventdate = @eventdate
	
		set @message = 'match_bk ==> currentdate: ' + convert(varchar(50), getdate(), 121) + ' - eventdate: ' + convert(varchar(50), @eventdate, 121) + ' - count: ' + cast(@@rowcount as varchar)
		raiserror (@message, 0, 1) with nowait

		set @eventdate = dateadd(day, 1, @eventdate)

	end
end
