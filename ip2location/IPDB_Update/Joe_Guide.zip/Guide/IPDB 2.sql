/****** Object:  UserDefinedFunction [dbo].[IP_DivideBy7Bytes]    Script Date: 1/4/2024 7:12:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

alter FUNCTION [dbo].[IP_DivideBy7Bytes]
(
	@input varchar(50)
)
RETURNS varchar(50)
BEGIN
	Declare @maxLen int         = LEN(@input)
	Declare @result varchar(50) = ''
	Declare @ipos int
	Declare @CurrentValue BIGINT

	SELECT @ipos = CASE WHEN @maxLen >= 17 THEN 17 ELSE @maxLen END
		 , @CurrentValue = CONVERT(BIGINT, LEFT(@input, @ipos))

	WHILE @ipos <= @maxLen
	BEGIN
		If @CurrentValue >= 72057594037927936
			SELECT @result = @result + LEFT( @CurrentValue/72057594037927936 , 1 ) -- divide result
				 , @CurrentValue = @CurrentValue % 72057594037927936 -- left over
		Else 
		BEGIN
			SET @ipos = @ipos + 1

			IF @ipos > @maxLen -- finished compute, convert leftover to HEX and append to result
				SET @result = @result + CONVERT(char(14),CONVERT(binary(7), CONVERT(BIGINT,@CurrentValue)),2)
			Else
			BEGIN -- get next value, add for next round calculation
				SET @CurrentValue = (@CurrentValue * 10) + CONVERT(tinyint, SUBSTRING(@input, @ipos, 1))
				IF @CurrentValue < 72057594037927936 AND @result <> '' SET @result = @result + '0'
			END
		END
	END

	RETURN @result
END
GO

/****** Object:  UserDefinedFunction [dbo].[IPv6_StringToHex]    Script Date: 1/4/2024 7:12:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


alter FUNCTION [dbo].[IPv6_StringToHex]
(
	@input varchar(50)
	--,@method tinyint
)
RETURNS binary(16)
AS
BEGIN
	DECLARE @result varchar(128)
	SET @input = LTRIM(RTRIM(@input))

-- 20201130 : test & create code to get data by doing base 2 and base 16
-- 20240102 : test & modify code to divide by 256, to get one byte data directly
-- 20240102 : test & modify code to divide by 65536, to get two bytes data directly
/*
	IF @method = 1
	BEGIN
		SET @result = dbo.IP_StringNumberToBase2(@input)
		SET @result = REPLACE(SPACE(128-LEN(@result)),' ','0') + @result

		SET @result = 
			dbo.IP_BitToHex(SUBSTRING(@result,  1,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,  5,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,  9,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 13,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 17,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 21,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 25,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 29,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 33,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 37,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 41,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 45,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 49,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 53,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 57,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 61,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 65,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 69,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 73,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 77,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 81,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 85,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 89,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 93,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result, 97,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,101,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,105,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,109,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,113,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,117,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,121,4)) +
			dbo.IP_BitToHex(SUBSTRING(@result,125,4))

	END

	IF @method = 2
	BEGIN
		SET @result = dbo.IP_StringNumberToBase16(@input)
		SET @result = REPLACE(SPACE(32-LEN(@result)),' ','0') + @result
	END

	IF @method = 3
	BEGIN
		SET @result = dbo.IP_StringNumberToByte(@input)
		SET @result = REPLACE(SPACE(32-LEN(@result)),' ','0') + @result
	END

	IF @method = 4
	BEGIN
		Declare @HexResult varchar(50)
		SET @HexResult = ''

		WHILE @input <> '0' AND @input <> ''
		BEGIN
			SELECT @result = dbo.IP_DivideBy65536(@input)
				 , @HexResult = RIGHT(@result, 4) + @HexResult
				 , @input = LEFT(@result, LEN(@result) - 4)
		END

		--SET @result = dbo.IP_StringNumberToDoubleByte(@input)
		SET @result = REPLACE(SPACE(32-LEN(@HexResult)),' ','0') + @HexResult
	END

	IF @method = 5
	BEGIN
		Declare @HexResult varchar(50)
		SET @HexResult = ''

		WHILE @input <> '0' AND @input <> ''
		BEGIN
			SELECT @result = dbo.IP_DivideBy4Bytes(@input)
				 , @HexResult = RIGHT(@result, 8) + @HexResult
				 , @input = LEFT(@result, LEN(@result) - 8)
		END

		--SET @result = dbo.IP_StringNumberToDoubleByte(@input)
		SET @result = REPLACE(SPACE(32-LEN(@HexResult)),' ','0') + @HexResult
	END

	IF @method = 6
*/
	BEGIN
		Declare @HexResult varchar(50)
		SET @HexResult = ''

		WHILE @input <> '0' AND @input <> ''
		BEGIN
			SELECT @result = dbo.IP_DivideBy7Bytes(@input)
				 , @HexResult = RIGHT(@result, 14) + @HexResult
				 , @input = LEFT(@result, LEN(@result) - 14)
		END

		--SET @result = dbo.IP_StringNumberToDoubleByte(@input)
		-- when run 3 pass, result length will be 7x3 = 21 bytes (42 char), useful data is only 16 bytes (32 char)
		SELECT @HexResult = CASE WHEN LEN(@HexResult) > 32 THEN RIGHT(@HexResult, 32) ELSE @HexResult END
		     , @result    = REPLACE(SPACE(32-LEN(@HexResult)),' ','0') + @HexResult
	END

	RETURN CONVERT(binary(16), @result, 2)
END
GO