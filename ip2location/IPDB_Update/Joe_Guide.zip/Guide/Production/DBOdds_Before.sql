truncate table TEMP_IPTable_Denied
truncate table TEMP_IPTable_Mini
GO
